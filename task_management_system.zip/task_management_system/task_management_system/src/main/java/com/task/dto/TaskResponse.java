package com.task.dto;

import java.time.LocalDate;

import com.task.model.Task;

public class TaskResponse {

	 private Long id;
	    private String title;
	    private String description;
	    private String status;
	    private String priority;
	    private LocalDate dueDate;

	    public TaskResponse(Task task) {
	        this.id = task.getId();
	        this.title = task.getTitle();
	        this.description = task.getDescription();
	        this.status = task.getStatus();
	        this.priority = task.getPriority();
	        this.dueDate = task.getDueDate();
	    }

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getPriority() {
			return priority;
		}

		public void setPriority(String priority) {
			this.priority = priority;
		}

		public LocalDate getDueDate() {
			return dueDate;
		}

		public void setDueDate(LocalDate dueDate) {
			this.dueDate = dueDate;
		}
	    
	    
}
