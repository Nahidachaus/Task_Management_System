package com.task.model;

public enum Role {
	USER,
    ADMIN
}
