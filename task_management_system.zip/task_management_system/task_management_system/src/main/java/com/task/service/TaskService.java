package com.task.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.task.dto.TaskRequest;
import com.task.dto.TaskResponse;
import com.task.model.Task;
import com.task.repository.TaskRepository;

@Service
public class TaskService {
	
	@Autowired
    private TaskRepository taskRepository;

    public TaskResponse createTask(TaskRequest request) {
        Task task = new Task();
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setStatus(request.getStatus());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        task = taskRepository.save(task);
        return new TaskResponse(task);
    }

    public List<TaskResponse> getTasks(String status, String priority, String dueDate, int page, int size) {
        Page<Task> taskPage = taskRepository.findAll(PageRequest.of(page, size));
        return taskPage.getContent().stream()
                .filter(task -> (status == null || task.getStatus().equals(status)) &&
                                (priority == null || task.getPriority().equals(priority)) &&
                                (dueDate == null || task.getDueDate().equals(dueDate)))
                .map(TaskResponse::new)
                .collect(Collectors.toList());
    }

    public TaskResponse updateTask(Long taskId, TaskRequest request) {
        Task task = taskRepository.findById(taskId)
                .orElseThrow(() -> new RuntimeException("Task not found"));
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setStatus(request.getStatus());
        task.setPriority(request.getPriority());
        task.setDueDate(request.getDueDate());
        task = taskRepository.save(task);
        return new TaskResponse(task);
    }

    public void deleteTask(Long taskId) {
        taskRepository.deleteById(taskId);
    }

}
