package com.task.util;

import java.security.SecureRandom;
import java.util.Base64;

public class JwtSecretKeyGenerator {

	private String getJwtSecretKey() {
		SecureRandom random = new SecureRandom();
		byte[] key = new byte[64]; // 512-bit key
		random.nextBytes(key);
		String jwtSecret = Base64.getEncoder().encodeToString(key);
		return jwtSecret;
	}
}
