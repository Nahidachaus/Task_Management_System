package com.task.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.task.model.User;
import com.task.repository.UserRepository;
import com.task.util.JwtUtil;

class UserServiceTest {

	@InjectMocks
	private UserService userService;

	@Mock
	private UserRepository userRepository;

	@Mock
	private PasswordEncoder passwordEncoder;

	@Mock
	private JwtUtil jwtUtil;

	public UserServiceTest() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testRegisterUser() {
		User user = new User();
		user.setUsername("testuser");
		user.setPassword("password");

		when(passwordEncoder.encode(user.getPassword())).thenReturn("encodedpassword");
		when(userRepository.save(user)).thenReturn(user);

		User registeredUser = userService.registerUser(user);

		assertEquals("testuser", registeredUser.getUsername());
		verify(userRepository, times(1)).save(user);
	}

	@Test
	void testAuthenticateUser() {
		User user = new User();
		user.setUsername("testuser");
		user.setPassword("encodedpassword");

		when(userRepository.findByUsername("testuser")).thenReturn(user);
		when(passwordEncoder.matches("password", user.getPassword())).thenReturn(true);
		when(jwtUtil.generateToken("testuser")).thenReturn("jwtToken");

		String token = userService.authenticateUser("testuser", "password");

		assertEquals("jwtToken", token);
	}
}
